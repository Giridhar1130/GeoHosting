import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eugene-component',
  templateUrl: './eugene-component.component.html',
  styleUrls: ['./eugene-component.component.css']
})
export class EugeneComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
