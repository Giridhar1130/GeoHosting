import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EugeneComponentComponent } from './eugene-component.component';

describe('EugeneComponentComponent', () => {
  let component: EugeneComponentComponent;
  let fixture: ComponentFixture<EugeneComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EugeneComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EugeneComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
