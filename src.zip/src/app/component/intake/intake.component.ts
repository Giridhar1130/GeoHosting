import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import {MatBottomSheet} from '@angular/material/bottom-sheet';
import { IntakeFormComponent } from '../intake-form/intake-form.component';
import {IntakeService} from '../../app.intake.service';
export interface IJsondate {
  name: string;
  ID: number;
  AssessmentStatus: string;
  symbol: string;
  scope: string;
  Owner: { Email: string, TypeId: string, LookupId: number, LookupValue: string };
}

const ELEMENT_DATA: IJsondate[] = [
  {
    ID: 413, name: 'Brazil Full Apr 2019', AssessmentStatus: 'Ready for Kickoff', symbol: '2-Medium', scope: 'Full', Owner: {
      Email: 'haguna@microsoft.com',
      TypeId: '{c956ab54-16bd-4c18-89d2-996f57282a6f}',
      LookupId: 713,
      LookupValue: 'Eric Roe'
    }
  },
  {
    ID: 450, name: 'SouthAfrica Full Refresh sep 2016', AssessmentStatus: 'Ready for Kickoff', symbol: '2-Medium', scope: 'Full', Owner: {
      Email: 'haguna@microsoft.com',
      TypeId: '{c956ab54-16bd-4c18-89d2-996f57282a6f}',
      LookupId: 713,
      LookupValue: 'Eric Roe'
    }
  },
  {
    ID: 418, name: 'Chile Full May 2019', AssessmentStatus: 'Ready for Kickoff', symbol: '2-Medium', scope: 'Full', Owner: {
      Email: 'haguna@microsoft.com',
      TypeId: '{c956ab54-16bd-4c18-89d2-996f57282a6f}',
      LookupId: 713,
      LookupValue: 'Hans Christian'
    }
  },
  {
    ID: 468, name: 'Brazil Full Apr 2019', AssessmentStatus: 'In Progress', symbol: '2-Medium', scope: 'Full', Owner: {
      Email: 'haguna@microsoft.com',
      TypeId: '{c956ab54-16bd-4c18-89d2-996f57282a6f}',
      LookupId: 713,
      LookupValue: 'Eric Roe'
    }
  },
  {
    ID: 520, name: 'Chile Full May 2019', AssessmentStatus: 'In Progress', symbol: '2-Medium', scope: 'Full', Owner: {
      Email: 'haguna@microsoft.com',
      TypeId: '{c956ab54-16bd-4c18-89d2-996f57282a6f}',
      LookupId: 713,
      LookupValue: 'Bill'
    }
  },
  {
    ID: 203, name: 'Turkey Full Refresh Sep 2016', AssessmentStatus: 'Completed', symbol: '2-Medium', scope: 'Full', Owner: {
      Email: 'haguna@microsoft.com',
      TypeId: '{c956ab54-16bd-4c18-89d2-996f57282a6f}',
      LookupId: 713,
      LookupValue: 'Jason'
    }
  },
  {
    ID: 415, name: 'Brazil Full Apr 2019', AssessmentStatus: 'Completed', symbol: '2-Medium', scope: 'Full', Owner: {
      Email: 'haguna@microsoft.com',
      TypeId: '{c956ab54-16bd-4c18-89d2-996f57282a6f}',
      LookupId: 713,
      LookupValue: 'Hans Christian'
    }
  },
];

@Component({
  selector: 'app-intake',
  templateUrl: './intake.component.html',
  styleUrls: ['./intake.component.css']
})
export class IntakeComponent implements OnInit {


  allIntakeData: any[];
  displayedColumns: string[] = ['ID', 'name', 'AssessmentStatus', 'symbol', 'scope'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  objectkeys = Object.keys;
  objectvalues = Object.values;
  tmpAssessmentStatus: string[] = [];
  leftItemOrginal: object[] = [];
  currentRightItem: IJsondate[] = ELEMENT_DATA;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  constructor(private bottomSheet: MatBottomSheet, private intakeService: IntakeService) { }
   getintakeInfo(): void {
    this.intakeService.getintake()
      .subscribe(async (callbackfromgetAPI: any[]) => {
       debugger;
       this.allIntakeData =  await callbackfromgetAPI;
       debugger
      });
     
  }
  rightChildrenSelected(target) {

    this.currentRightItem = ELEMENT_DATA.filter((items: IJsondate) => items.Owner.
      LookupValue === target.Owner.LookupValue && items.AssessmentStatus === target.AssessmentStatus
    );
    this.dataSource = new MatTableDataSource(this.currentRightItem);
    this.dataSource.sort = this.sort;
  }

  // public expandedHandler(){
  //   return this.objectkeys === 'Ready for Kickoff';
  // }
  afterLeftRootCollapse(ev) {
    this.currentRightItem = this.currentRightItem.filter((items: IJsondate) => !(items.AssessmentStatus === ev[0]));
    this.dataSource = new MatTableDataSource(this.currentRightItem);
    this.dataSource.sort = this.sort;
  }
  afterLeftRootExpend(ev) {
    console.log(ev, this.currentRightItem);
    this.currentRightItem = this.currentRightItem.concat(ELEMENT_DATA.filter((items: IJsondate) => items.AssessmentStatus === ev[0]));
    this.dataSource = new MatTableDataSource(this.currentRightItem);
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource.sort = this.sort;
  }
  showALl() {
    this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    this.dataSource.sort = this.sort;
  }

getdata(data){
  data.map((items: IJsondate) => {

    if (!this.tmpAssessmentStatus.includes(items.AssessmentStatus)) {
      this.tmpAssessmentStatus.push(items.AssessmentStatus);
      const tmpobject: {} = {};
      tmpobject[items.AssessmentStatus] = [items];
      this.leftItemOrginal.push(tmpobject);
    } else {
      this.leftItemOrginal.filter((item: IJsondate) =>{
        console.log(Object.values(item)[0][0].Owner.LookupValue)
      })
      
      // if ((this.leftItemOrginal.filter((item: IJsondate) =>
      //   Object.values(item)[0].filter((target:IJsondate )=>target.Owner.LookupValue=== items.Owner.LookupValue) )).length < 1) {
      //     console.log(Object.values(this.leftItemOrginal[0])[0].filter,items.Owner.LookupValue);
      //   this.leftItemOrginal.filter((item: object) => Object.keys(item)[0] === items.AssessmentStatus)
      //   [0][items.AssessmentStatus].push(items);
      // }
    }

  });

}
  openBottomSheet(element): void {
    console.log(element);

    this.bottomSheet.open(IntakeFormComponent, {data: element, panelClass: 'intakeFomrbody'});
  }
  async ngOnInit() {
    
    this.intakeService.getintake()
    .subscribe(async (callbackfromgetAPI: any[]) => {
     this.allIntakeData =  await callbackfromgetAPI;
     this.getdata(this.allIntakeData);  
    });
        
    console.log(this.leftItemOrginal, this.allIntakeData);

    this.dataSource.sort = this.sort;


  }


}
