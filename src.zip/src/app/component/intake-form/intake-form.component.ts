import { Component, OnInit, Inject} from '@angular/core';
import { MatBottomSheetRef} from '@angular/material/bottom-sheet';
import {MAT_BOTTOM_SHEET_DATA} from '@angular/material';
import { MatTableDataSource } from '@angular/material/table';


export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}
const ELEMENT_DATA: Element[] = [

];
const elementContext: Element = {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'};

export interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-intakeform',
  templateUrl: './intake-form.component.html',
  styleUrls: ['./intake-form.component.css'],

})
export class IntakeFormComponent implements OnInit {
 // constructor(@Inject(MAT_BOTTOM_SHEET_DATA) public element: any, private bottomSheetRef: MatBottomSheetRef<IntakeFormComponent>) {}

  // openLink(event: MouseEvent): void {
  //   this.bottomSheetRef.dismiss();
  //   event.preventDefault();
  // }

  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  contryList = [
    { ID: 123, Value: 'Chile' },
    { ID: 234, Value: 'Italy' },
    { ID: 456, Value: 'France' },
    { ID: 68, Value: 'Spain' },
    { ID: 88, Value: 'Japan' }
  ];
  prorityList: string[] = ['High', 'Medium', 'Low'];
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  scopeList: object[] = [{ID: 123, Value: 'Full'}, {ID: 345, Value: 'Edge'}, {ID: 567, Value: 'Full Refresh'}];
  prorityChoice: string;

  dataSource = new MatTableDataSource(ELEMENT_DATA);
  private positon = 2;
  submitted = false;
 private addonsite() {
   const tmp: Element = Object.assign({}, elementContext);
   tmp.position = this.positon++ ;

   ELEMENT_DATA.push(tmp);
   console.log(ELEMENT_DATA);
   this.dataSource = new MatTableDataSource(ELEMENT_DATA);


  }
  onSubmit(e) {
    console.log(e);
    this.submitted = true; }
    ngOnInit() {
      ELEMENT_DATA.push(elementContext);
      this.dataSource = new MatTableDataSource(ELEMENT_DATA);
   //   console.log('child', this.element);
    }
  }
