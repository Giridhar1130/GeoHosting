import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { IntakeComponent } from './component/intake/intake.component';
import { EugeneComponentComponent } from './component/eugene-component/eugene-component.component';
import { IntakeFormComponent } from './component/intake-form/intake-form.component';
import { HomeComponent } from './component/home/home.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'intake', component: IntakeComponent },
  { path: 'euge', component: EugeneComponentComponent },
  {path: 'intakeform', component: IntakeFormComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
